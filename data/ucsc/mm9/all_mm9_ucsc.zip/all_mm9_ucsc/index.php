<?php
header('Location: http://bioinfo.au.tsinghua.edu.cn/software/dbSE/');
?>